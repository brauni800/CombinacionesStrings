package filtrosTuberias;

public class Main {

	public static void main(String[] args) {
		Logica log = new Logica();
		log.start(args);
	}
}
